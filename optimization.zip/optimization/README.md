# Railway Optimization V2.7

Upgraded five-objective NSGA-II model.

Objectives:
1. Minimize passenger waiting
2. Minimize overcrowding
3. Maximize capacity utilization
4. Minimize disruption robustness cost
5. Minimize schedule deviation

Constraints:
- minimum same-direction headway
- time-dependent coach fleet availability

Copy:
data/timetable/mainline_timetable_2026_04_19.csv
data/passenger/corridor_segment_demand.csv

Then run:
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python optimization/run_nsga2_v27.py

Outputs:
results/pareto_solutions_v27.csv
results/pareto_front_v27.png
results/nsga2_convergence_v27.csv

Note: service duration, coach capacity and peak-demand share remain explicit
prototype assumptions until verified data/Component 1 outputs are available.
