import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path

st.set_page_config(page_title="AI Railway Operations V2.9", page_icon="🚆", layout="wide")

BASE = Path(__file__).resolve().parent
RESULTS = BASE / "results"

def load_data():
    for name in ["balanced_solution_v27.csv", "pareto_solutions_v27.csv", "pareto_solutions_v22.csv"]:
        p = RESULTS / name
        if p.exists():
            try:
                d = pd.read_csv(p)
                if not d.empty:
                    return d, name
            except Exception:
                pass
    return pd.DataFrame({
        "train_no":[1537,1535,6012,8056,8062,1004,1008,1012,1016,1020],
        "departure_time":["05:20","05:25","06:10","06:35","07:05","07:30","08:00","08:30","09:00","09:30"],
        "direction":["Up","Up","Up","Down","Down","Up","Up","Down","Down","Up"],
        "coaches":[6]*10,
        "estimated_demand":[413,344,1859,546,784,1015,1295,924,686,532]
    }), "built-in demo data"

def col(d, names):
    for n in names:
        for c in d.columns:
            if str(c).lower() == n.lower() or n.lower() in str(c).lower():
                return c
    return None

df, source = load_data()
train = col(df, ["train_no","train"])
time = col(df, ["departure_time","departure"])
direction = col(df, ["direction"])
coaches = col(df, ["coaches","coach"])
demand = col(df, ["estimated_demand","demand","passenger_demand"])

if train is None:
    df["train_no"] = range(1,len(df)+1); train="train_no"
if coaches is None:
    df["coaches"] = 6; coaches="coaches"
if demand is None:
    df["estimated_demand"] = 300; demand="estimated_demand"
if time is None:
    df["departure_time"] = "05:20"; time="departure_time"
if direction is None:
    df["direction"] = "Up"; direction="direction"

df[coaches] = pd.to_numeric(df[coaches], errors="coerce").fillna(6)
df[demand] = pd.to_numeric(df[demand], errors="coerce").fillna(300)

st.markdown("# 🚆 AI-Driven Intelligent Railway Operations System")
st.caption("Multi-Objective Train Scheduling & Capacity Management — NSGA-II V2.9")
st.sidebar.title("🚆 Control Panel")
page = st.sidebar.radio("Navigation", [
    "Operator Input & Optimization","Operations Overview",
    "Schedule Optimization","Demand Intelligence","Delay & Resilience",
    "Pareto Analysis","Simulation & Validation"
])
st.sidebar.success("NSGA-II V2.9 ENGINE")
st.sidebar.caption(f"Base data: {source}")

if "result" not in st.session_state:
    st.session_state.result = None

if page == "Operator Input & Optimization":
    st.header("🎛️ Operator Input & Optimization")
    a,b = st.columns(2)

    with a:
        demand_level = st.slider("Passenger demand level",0.50,1.50,0.70,0.05)
        fleet = st.number_input("Available coaches in fleet",12,150,96,1)
        cap = st.number_input("Passenger capacity per coach",20,60,50,1)
        min_c = st.number_input("Minimum coaches/train",1,6,3,1)
        max_c = st.number_input("Maximum coaches/train",int(min_c),6,6,1)

    with b:
        trains = ["None"] + [str(x) for x in df[train].tolist()]
        affected = st.selectbox("Affected train",trains)
        delay = st.slider("Disruption delay (minutes)",0,60,10,5)
        max_shift = st.slider("Maximum timetable shift (minutes)",0,15,5,1)

    st.info("Sri Lanka-oriented constraint: maximum 6 coaches per train and 50 passengers per coach by default. Fleet is a shared pool.")

    if st.button("🚀 RUN OPERATOR SCENARIO", use_container_width=True, type="primary"):
        w=df.copy()
        w["scenario_demand"]=w[demand]*demand_level
        w["recommended_coaches"]=w[coaches].round().clip(min_c,max_c).astype(int)

        used=int(w["recommended_coaches"].sum())

        # Repair fleet if the starting timetable uses too many coaches.
        for i in w.sort_values("scenario_demand").index:
            while used>fleet and w.loc[i,"recommended_coaches"]>min_c:
                w.loc[i,"recommended_coaches"]-=1
                used-=1

        # Give spare coaches to highest-demand trains first.
        for i in w.sort_values("scenario_demand",ascending=False).index:
            while used<fleet and w.loc[i,"recommended_coaches"]<max_c:
                w.loc[i,"recommended_coaches"]+=1
                used+=1

        w["capacity"]=w["recommended_coaches"]*cap
        w["overcrowding"]=np.maximum(w["scenario_demand"]-w["capacity"],0)
        w["utilization"]=np.minimum(w["scenario_demand"]/w["capacity"].replace(0,np.nan),1).fillna(0)
        w["shift_min"]=0.0

        if affected!="None":
            mask=w[train].astype(str)==affected
            w.loc[mask,"shift_min"]=min(delay,max_shift)

        total_demand=float(w["scenario_demand"].sum())
        over=float(w["overcrowding"].sum())
        util=100*total_demand/max(float(w["capacity"].sum()),1)
        pressure=over/max(total_demand,1)
        waiting=10+25*pressure+0.15*(delay if affected!="None" else 0)
        robustness=float(w["shift_min"].abs().sum()+0.8*(delay if affected!="None" else 0))
        stability=float(w["shift_min"].abs().mean())

        if over>0.30*total_demand:
            status="🔴 Severe capacity pressure"
        elif over>0.10*total_demand:
            status="🟡 Capacity pressure"
        elif delay>0 and affected!="None":
            status="🟠 Disruption response required"
        else:
            status="🟢 Operationally acceptable"

        st.session_state.result={
            "w":w,"waiting":waiting,"over":over,"util":util,
            "robustness":robustness,"stability":stability,"status":status,
            "affected":affected,"delay":delay,"fleet":fleet,
            "cap":cap,"demand_level":demand_level
        }

    r=st.session_state.result
    if r:
        st.success("Scenario processed successfully.")
        st.subheader("🤖 System Response")
        c=st.columns(5)
        for x,title,val in zip(c,["Waiting","Overcrowding","Utilization","Robustness","Stability"],
                               [f"{r['waiting']:.2f} min",f"{r['over']:,.0f}",f"{r['util']:.2f}%",f"{r['robustness']:.2f}",f"{r['stability']:.2f} min/train"]):
            x.metric(title,val)

        st.subheader("Situation Assessment")
        st.warning(r["status"]) if "🔴" in r["status"] or "🟡" in r["status"] else st.success(r["status"])

        st.subheader("🎯 Recommended Operational Actions")
        if r["over"]>0:
            st.write("• Prioritize the highest-demand services for available coaches.")
            st.write("• Keep every train within the configured 3–6 coach limit.")
            st.write("• Use timetable shifts only within the operator-defined limit.")
            st.write("• Re-run the scenario after changing demand, fleet or disruption.")
        elif r["delay"]>0:
            st.write("• Prioritize the affected train and apply the smallest permitted shift.")
        else:
            st.write("• Retain the current optimized plan; capacity pressure is acceptable.")

        st.subheader("🚨 Highest-Priority Services")
        p=r["w"].sort_values(["overcrowding","scenario_demand"],ascending=False).head(10)
        show=p[[train,time,direction,"recommended_coaches","scenario_demand","capacity","utilization","overcrowding","shift_min"]].copy()
        show.columns=["Train","Scheduled","Direction","Recommended Coaches","Demand","Capacity","Utilization","Overcrowding","Shift (min)"]
        show["Utilization"]=(show["Utilization"]*100).round(1).astype(str)+"%"
        st.dataframe(show,use_container_width=True,hide_index=True)

        csv=show.to_csv(index=False).encode()
        st.download_button("⬇️ Download Recommended Scenario CSV",csv,"operator_recommended_scenario_v29.csv","text/csv")

elif page=="Operations Overview":
    st.header("📊 Operations Overview")
    if st.session_state.result:
        r=st.session_state.result
        c=st.columns(5)
        for x,t,v in zip(c,["Waiting","Overcrowding","Utilization","Robustness","Stability"],
                          [r["waiting"],r["over"],r["util"],r["robustness"],r["stability"]]):
            x.metric(t,round(v,2))
    else:
        st.info("Run an operator scenario first.")

elif page=="Schedule Optimization":
    st.header("📅 Schedule Optimization")
    st.dataframe(df[[x for x in [train,time,direction,coaches,demand] if x]],use_container_width=True,hide_index=True)

elif page=="Demand Intelligence":
    st.header("👥 Demand Intelligence")
    x=df[[train,demand]].copy().set_index(train)
    st.bar_chart(x)

elif page=="Delay & Resilience":
    st.header("⚠️ Delay & Resilience")
    if st.session_state.result:
        r=st.session_state.result
        st.metric("Affected train",r["affected"])
        st.metric("Disruption delay",f"{r['delay']} min")
        st.metric("Average timetable shift",f"{r['stability']:.2f} min/train")
    else:
        st.info("Run an operator scenario first.")

elif page=="Pareto Analysis":
    st.header("🎯 Pareto Analysis")
    p=RESULTS/"pareto_solutions_v27.csv"
    if p.exists():
        d=pd.read_csv(p)
        x=col(d,["waiting_objective","waiting"])
        y=col(d,["overcrowding_objective","overcrowding"])
        if x and y:
            st.scatter_chart(d[[x,y]].dropna().set_index(x),y=y)
        else:
            st.dataframe(d,use_container_width=True)
    else:
        st.info("Pareto CSV not found in results/.")

else:
    st.header("🧪 Simulation & Validation")
    p=RESULTS/"nsga2_convergence_v27.csv"
    if p.exists():
        d=pd.read_csv(p)
        st.line_chart(d.select_dtypes(include=np.number))
    else:
        st.info("Run the NSGA-II optimizer to generate convergence evidence.")
    st.success("Physical constraints used by V2.9: max 6 coaches/train; 50 passengers/coach default; shared fleet pool; bounded timetable shift.")

st.divider()
st.caption("V2.9 is a decision-support scenario layer using the V2.7 NSGA-II result as its base plan. It should not be described as a fresh NSGA-II run unless the optimizer is executed for the new scenario.")
