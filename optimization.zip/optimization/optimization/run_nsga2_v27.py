
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pymoo.core.problem import ElementwiseProblem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.operators.sampling.rnd import IntegerRandomSampling
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM

ROOT=Path(__file__).resolve().parents[1]
TT=ROOT/"data/timetable/mainline_timetable_2026_04_19.csv"
DEM=ROOT/"data/passenger/corridor_segment_demand.csv"
OUT=ROOT/"results"; OUT.mkdir(exist_ok=True)

SHIFT_MIN,SHIFT_MAX=-5,5
MIN_HEADWAY=5
MIN_COACHES,MAX_COACHES=6,12
FLEET_COACHES=96
SERVICE_DURATION_MIN=120
CAPACITY_PER_COACH=80
PEAK_SHARE=.20
DELAYS=[5,10,15]
WINDOWS=[(300,540),(960,1200)]
POP=180
GEN=220

def tm(s):
    h,m=map(int,str(s).split(":")); return h*60+m
def clock(v):
    v=int(round(v))%(24*60); return f"{v//60:02d}:{v%60:02d}"

if not TT.exists() or not DEM.exists():
    raise FileNotFoundError("Copy mainline_timetable_2026_04_19.csv into data/timetable and corridor_segment_demand.csv into data/passenger.")

tt=pd.read_csv(TT); dem=pd.read_csv(DEM)
tt["dep_min"]=tt.departure_time.map(tm)
sel=tt[tt.dep_min.apply(lambda t:any(a<=t<=b for a,b in WINDOWS))].copy()
sel=sel.sort_values(["direction","dep_min","train_no"]).reset_index(drop=True)
N=len(sel)
if N==0: raise RuntimeError("No services selected.")
daily=float(dem.two_way_daily_demand.sum()); peak=daily*PEAK_SHARE

# Prototype time-demand profile. Replace with Component 1 output later.
def arrivals():
    mt=np.arange(305,540,10); et=np.arange(965,1200,10)
    mw=np.array([.05,.07,.10,.13,.15,.14,.12,.10,.07,.04,.03])[:len(mt)]
    ew=np.array([.04,.06,.08,.10,.12,.14,.15,.12,.09,.06,.04])[:len(et)]
    mw/=mw.sum(); ew/=ew.sum()
    return [(int(t),peak*.5*w) for t,w in zip(mt,mw)]+[(int(t),peak*.5*w) for t,w in zip(et,ew)]
ARR=arrivals()

def decode(x):
    sh=np.rint(x[:N]).astype(int); co=np.rint(x[N:]).astype(int)
    dep=sel.dep_min.to_numpy(int)+sh
    return dep,sh,co

def headway(dep):
    v=0.; dirs=sel.direction.to_numpy()
    for d in sel.direction.unique():
        idx=np.where(dirs==d)[0]; t=np.sort(dep[idx])
        if len(t)>1: v+=np.maximum(MIN_HEADWAY-np.diff(t),0).sum()
    return float(v)

def fleet(dep,co):
    ev=[]
    for t,c in zip(dep,co):
        ev += [(t,int(c)),(t+SERVICE_DURATION_MIN,-int(c))]
    ev.sort(key=lambda z:(z[0],-z[1])); active=0; prev=ev[0][0]; v=0.
    for t,ch in ev:
        if active>FLEET_COACHES: v+=(active-FLEET_COACHES)*(t-prev)
        active+=ch; prev=t
    return float(v)

def assign(dep):
    dirs=sel.direction.to_numpy(); td=np.zeros(N); wait=np.zeros(N); un=0.
    for at,amount in ARR:
        for d in ["Up","Down"]:
            a=amount*.5; idx=np.where(dirs==d)[0]
            f=idx[dep[idx]>=at]
            if len(f)==0: un+=a; continue
            j=f[np.argmin(dep[f])]; w=dep[j]-at
            td[j]+=a; wait[j]+=a*w
    return td,wait,un

def metrics(td,co):
    cap=co*CAPACITY_PER_COACH
    served=np.minimum(td,cap)
    over=np.maximum(td-cap,0)
    util=served.sum()/max(cap.sum(),1)
    return cap,served,over,util

def robustness(dep,co):
    vals=[]
    for delay in DELAYS:
        d=dep.copy(); k=int(np.argmin(np.abs(d-np.median(d)))); d[k]+=delay
        td,w,u=assign(d); cap,served,over,util=metrics(td,co)
        vals.append((w.sum()+over.sum()+u*120)/max(peak,1))
    return float(np.mean(vals))

def obj(x):
    dep,sh,co=decode(x); td,w,u=assign(dep); cap,served,over,util=metrics(td,co)
    f1=(w.sum()+u*120)/max(peak,1)
    f2=float(over.sum())
    f3=1-util
    f4=robustness(dep,co)
    f5=float(np.abs(sh).sum()/max(N,1))
    return np.array([f1,f2,f3,f4,f5])

class RailwayProblem(ElementwiseProblem):
    def __init__(self):
        super().__init__(n_var=2*N,n_obj=5,n_ieq_constr=2,
                         xl=np.array([SHIFT_MIN]*N+[MIN_COACHES]*N),
                         xu=np.array([SHIFT_MAX]*N+[MAX_COACHES]*N),
                         vtype=int)
    def _evaluate(self,x,out,*args,**kwargs):
        dep,sh,co=decode(x)
        out["F"]=obj(x)
        out["G"]=np.array([headway(dep),fleet(dep,co)])

def maxsim(dep,co):
    ev=[]
    for t,c in zip(dep,co): ev += [(t,int(c)),(t+SERVICE_DURATION_MIN,-int(c))]
    ev.sort(key=lambda z:(z[0],-z[1])); a=m=0
    for _,ch in ev: a+=ch; m=max(m,a)
    return m

print("="*70)
print("SRI LANKA RAILWAY - NSGA-II V2.7")
print("="*70)
print(f"Services: {N} | Demand: {daily:,.0f} | Peak prototype demand: {peak:,.0f}")
print("Five objectives: waiting, overcrowding, utilization, robustness, schedule stability")
res=minimize(RailwayProblem(),NSGA2(pop_size=POP,sampling=IntegerRandomSampling(),
    crossover=SBX(prob=.9,eta=15,vtype=float),
    mutation=PM(prob=1/(2*N),eta=20,vtype=float)),
    termination=("n_gen",GEN),seed=42,verbose=True,save_history=True)
if res.X is None or res.F is None: raise RuntimeError("NSGA-II returned no feasible solutions.")

rows=[]
for x,f in zip(res.X,res.F):
    dep,sh,co=decode(x); td,w,u=assign(dep); cap,served,over,util=metrics(td,co)
    r={"waiting_objective":f[0],"overcrowding_objective":f[1],
       "utilization_objective":1-f[2],"robustness_objective":f[3],
       "schedule_deviation_objective":f[4],"total_coach_assignments":int(co.sum()),
       "max_simultaneous_coaches":maxsim(dep,co),"fleet_coach_limit":FLEET_COACHES,
       "unserved_passengers":u}
    for i in range(N):
        tr=str(sel.iloc[i].train_no)
        r[f"{tr}_scheduled"]=sel.iloc[i].departure_time
        r[f"{tr}_optimized"]=clock(dep[i])
        r[f"{tr}_shift_min"]=int(sh[i])
        r[f"{tr}_coaches"]=int(co[i])
        r[f"{tr}_demand"]=round(float(td[i]),2)
        r[f"{tr}_capacity"]=int(cap[i])
        r[f"{tr}_utilization"]=round(float(util if cap.sum()==0 else served[i]/max(cap[i],1)),4)
        r[f"{tr}_overcrowding"]=round(float(over[i]),2)
    rows.append(r)

pd.DataFrame(rows).to_csv(OUT/"pareto_solutions_v27.csv",index=False)
plt.figure(figsize=(10,6))
plt.scatter([r["waiting_objective"] for r in rows],[r["overcrowding_objective"] for r in rows],s=30)
plt.xlabel("Passenger Waiting Objective"); plt.ylabel("Overcrowding Objective")
plt.title("NSGA-II V2.7 Five-Objective Pareto Solutions"); plt.grid(alpha=.3)
plt.tight_layout(); plt.savefig(OUT/"pareto_front_v27.png",dpi=180); plt.close()

hist=[]
for g,a in enumerate(res.history,1):
    fs=[i.F for i in a.pop if i.F is not None and np.maximum(i.G,0).sum()<=1e-9]
    if fs:
        fs=np.asarray(fs); hist.append({"generation":g,"best_waiting":fs[:,0].min(),
        "best_overcrowding":fs[:,1].min(),"best_utilization_inefficiency":fs[:,2].min(),
        "best_robustness":fs[:,3].min(),"best_schedule_deviation":fs[:,4].min(),
        "feasible_solutions":len(fs)})
if hist: pd.DataFrame(hist).to_csv(OUT/"nsga2_convergence_v27.csv",index=False)

print("COMPLETED")
print("Pareto solutions:",len(rows))
print("Best waiting:",min(r["waiting_objective"] for r in rows))
print("Best overcrowding:",min(r["overcrowding_objective"] for r in rows))
print("Best utilization:",max(r["utilization_objective"] for r in rows))
print("Best robustness:",min(r["robustness_objective"] for r in rows))
print("Best schedule deviation:",min(r["schedule_deviation_objective"] for r in rows))
print("Saved results/pareto_solutions_v27.csv")
print("Saved results/pareto_front_v27.png")
print("Saved results/nsga2_convergence_v27.csv")
