
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

pareto_file = RESULTS / "pareto_solutions_v27.csv"
conv_file = RESULTS / "nsga2_convergence_v27.csv"

if not pareto_file.exists():
    raise FileNotFoundError(
        "Copy pareto_solutions_v27.csv into results/ before running."
    )

df = pd.read_csv(pareto_file)

# Numeric conversion
objective_cols = [
    "waiting_objective",
    "overcrowding_objective",
    "utilization_objective",
    "robustness_objective",
    "schedule_deviation_objective",
]
for c in objective_cols:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# Balanced solution: normalized distance to ideal point.
bad = df.copy()
bad["_util_bad"] = 1 - bad["utilization_objective"]
score_cols = [
    "waiting_objective",
    "overcrowding_objective",
    "_util_bad",
    "robustness_objective",
    "schedule_deviation_objective",
]
norm = pd.DataFrame(index=bad.index)
for c in score_cols:
    lo, hi = bad[c].min(), bad[c].max()
    norm[c] = (bad[c] - lo) / (hi - lo) if hi > lo else 0
bad["_balanced_score"] = np.sqrt((norm ** 2).sum(axis=1))
balanced = bad.loc[bad["_balanced_score"].idxmin()]

# Summary
summary = pd.DataFrame([
    ["Pareto solutions", len(df), "Higher indicates more candidate solutions"],
    ["Best passenger waiting", df.waiting_objective.min(), "Lower is better"],
    ["Best overcrowding", df.overcrowding_objective.min(), "Lower is better"],
    ["Best utilization", df.utilization_objective.max(), "Higher is better"],
    ["Best robustness", df.robustness_objective.min(), "Lower is better"],
    ["Best schedule deviation", df.schedule_deviation_objective.min(), "Lower is better"],
    ["Balanced waiting", balanced.waiting_objective, "Selected balanced solution"],
    ["Balanced overcrowding", balanced.overcrowding_objective, "Selected balanced solution"],
    ["Balanced utilization", balanced.utilization_objective, "Selected balanced solution"],
    ["Balanced robustness", balanced.robustness_objective, "Selected balanced solution"],
    ["Balanced schedule deviation", balanced.schedule_deviation_objective, "Selected balanced solution"],
], columns=["Metric", "Value", "Interpretation"])

summary.to_csv(RESULTS / "final_kpi_summary_v27.csv", index=False)

# Full balanced row
pd.DataFrame([balanced.drop(labels=["_util_bad", "_balanced_score"], errors="ignore")]).to_csv(
    RESULTS / "balanced_solution_v27.csv", index=False
)

# Feasibility checks
checks = []
checks.append(["Pareto solutions exist", len(df) > 0, len(df)])
if "max_simultaneous_coaches" in df.columns and "fleet_coach_limit" in df.columns:
    peak = df.max_simultaneous_coaches.max()
    limit = df.fleet_coach_limit.max()
    checks.append(["Fleet capacity constraint", peak <= limit, f"{peak} / {limit}"])
if "unserved_passengers" in df.columns:
    unserved = df.unserved_passengers.max()
    checks.append(["Unserved passenger constraint", unserved <= 0, unserved])

pd.DataFrame(checks, columns=["Check", "PASS", "Value"]).to_csv(
    RESULTS / "feasibility_checks_v27.csv", index=False
)

# Pareto projection
plt.figure(figsize=(9,6))
plt.scatter(df["waiting_objective"], df["overcrowding_objective"], alpha=0.75)
plt.scatter(
    balanced["waiting_objective"],
    balanced["overcrowding_objective"],
    marker="*",
    s=220,
    label="Balanced solution",
)
plt.xlabel("Passenger Waiting Objective")
plt.ylabel("Overcrowding Objective")
plt.title("NSGA-II V2.7 Pareto Solutions")
plt.legend()
plt.tight_layout()
plt.savefig(RESULTS / "final_pareto_front_v27.png", dpi=220)
plt.close()

# Convergence
if conv_file.exists():
    conv = pd.read_csv(conv_file)
    plt.figure(figsize=(10,6))
    cols = [
        ("best_waiting", "Passenger Waiting"),
        ("best_overcrowding", "Overcrowding"),
        ("best_robustness", "Robustness"),
        ("best_schedule_deviation", "Schedule Deviation"),
    ]
    plotted = False
    for col, label in cols:
        if col in conv.columns:
            plt.plot(conv["generation"], conv[col], label=label)
            plotted = True
    if plotted:
        plt.xlabel("Generation")
        plt.ylabel("Objective value")
        plt.title("NSGA-II V2.7 Convergence")
        plt.legend()
        plt.tight_layout()
        plt.savefig(RESULTS / "final_convergence_v27.png", dpi=220)
    plt.close()

print("\n==============================================")
print(" FINAL V2.7 VALIDATION COMPLETED")
print("==============================================")
print(f"Pareto solutions : {len(df)}")
print(f"Best waiting     : {df.waiting_objective.min():.2f}")
print(f"Best overcrowding: {df.overcrowding_objective.min():,.2f}")
print(f"Best utilization : {df.utilization_objective.max()*100:.2f}%")
print(f"Best robustness  : {df.robustness_objective.min():.2f}")
print(f"Best stability   : {df.schedule_deviation_objective.min():.2f} min/train")
print("----------------------------------------------")
print("BALANCED SOLUTION")
print(f"Waiting          : {balanced.waiting_objective:.2f}")
print(f"Overcrowding     : {balanced.overcrowding_objective:,.2f}")
print(f"Utilization      : {balanced.utilization_objective*100:.2f}%")
print(f"Robustness       : {balanced.robustness_objective:.2f}")
print(f"Schedule deviation: {balanced.schedule_deviation_objective:.2f} min/train")
print("----------------------------------------------")
print("Files saved in results/:")
print("final_kpi_summary_v27.csv")
print("balanced_solution_v27.csv")
print("feasibility_checks_v27.csv")
print("final_pareto_front_v27.png")
print("final_convergence_v27.png (if convergence CSV exists)")
